<?php
require 'connect.php';
require 'includes/session.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['changePassword'])) {
    $currentPassword = $_POST['currentPassword'] ?? '';
    $newPassword = $_POST['newPassword'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $userId = $_SESSION['user']['idUser'];

    $stmt = $pdo->prepare("SELECT * FROM NguoiDung WHERE idUser = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($currentPassword, $user['Password'])) {
        echo "<script>alert('Mật khẩu hiện tại không đúng.');</script>";
    } elseif ($newPassword !== $confirmPassword) {
        echo "<script>alert('Xác nhận mật khẩu mới không khớp.');</script>";
    } elseif (strlen($newPassword) > 20) {
        echo "<script>alert('Mật khẩu quá dài (tối đa 20 ký tự).');</script>";
    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE NguoiDung SET Password = ? WHERE idUser = ?");
        $update->execute([$hashedPassword, $userId]);

        echo "<script>alert('Đổi mật khẩu thành công!'); window.location.href = 'changepass.php';</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="vi">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <title>Đổi mật khẩu</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Open+Sans:wght@400;500;600&family=Playfair+Display:wght@700&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="stylesheet" href="css/main-fixes.css">
  <link rel="stylesheet" href="css/account.css">
  <link rel="stylesheet" href="css/footer-modern.css">
  <link rel="stylesheet" href="css/security.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    integrity="sha512-v+CMEg1a6z5iIYHhq6J2wB1Q1lm9Efdv7p5TgDcN8IkKqzDnKbcZH3yHhAqT1Mn9sk9ms5mW9Z+dSbRUz7F+jQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<div id="notification-popup" style="
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    padding: 12px 20px;
    border-radius: 8px;
    background-color: #333;
    color: #fff;
    font-size: 0.95rem;
    display: none;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    animation: fadeInOut 3s ease-in-out;
"></div>

<body>


  <?php include 'header.php'; ?>

  <main>
    <div class="container dashboard-page">
      <div class="dashboard-content">
        <!-- Sidebar -->
        <div class="dashboard-sidebar">
          <div class="sidebar-header">
            <div class="user-profile">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80"
                alt="User avatar" class="user-avatar">
              <div class="user-name">Nguyễn Văn Anh</div>
              <div class="user-email">nguyenvananh@gmail.com</div>
              <div class="user-email">Khoa Công nghệ Thông Tin</div>
              <div class="user-status">
                <span class="user-status-icon"></span>
                Tài khoản Premium
              </div>
            </div>
          </div>

          <ul class="sidebar-menu">
            <li class="sidebar-menu-title">Tài liệu</li>
            <li class="sidebar-menu-item">
              <a href="mydocuments.php" class="sidebar-menu-link">
                <i class="fas fa-file-alt sidebar-icon"></i>
                Tài liệu của tôi
                <span class="sidebar-badge">15</span>
              </a>
            </li>

            <li class="sidebar-menu-item">
              <a href="upload.php" class="sidebar-menu-link">
                <i class="fas fa-cloud-upload-alt sidebar-icon"></i>
                Tải lên tài liệu
              </a>
            </li>

            <li class="sidebar-menu-title">Tài khoản</li>

            <li class="sidebar-menu-item">
              <a href="changepass.php" class="sidebar-menu-link">
                <i class="fas fa-user sidebar-icon"></i>
                Đổi mật khẩu
              </a>
            </li>
        </div>

        <!-- Main Content -->
        <div class="dashboard-main">
          <form method="post" action="">
            <div class="dashboard-section">
              <div class="section-header">
                <h2 class="section-title">
                  <i class="fas fa-key section-title-icon"></i>
                  Đổi mật khẩu
                </h2>
              </div>

              <div class="security-settings">
                <div class="sec-section">
                  <label class="sec-label">Mật khẩu hiện tại <span class="required">*</span></label>
                  <div class="input-wrapper">
                    <input type="password" class="sec-input" id="currentPassword" name="currentPassword" placeholder="Nhập mật khẩu hiện tại" required>
                    <i class="fa-solid fa-eye toggle-password" onclick="togglePassword(this, 'currentPassword')"></i>
                  </div>

                  <label class="sec-label">Mật khẩu mới <span class="required">*</span></label>
                  <div class="input-wrapper">
                    <input type="password" class="sec-input" id="newPassword" name="newPassword" placeholder="Nhập mật khẩu mới" maxlength="20" required>
                    <i class="fa-solid fa-eye toggle-password" onclick="togglePassword(this, 'newPassword')"></i>
                    <small id="lengthWarning" style="color: red; display: none;">⚠️ Tối đa 20 ký tự</small>
                  </div>

                  <label class="sec-label">Xác nhận mật khẩu mới <span class="required">*</span></label>
                  <div class="input-wrapper">
                    <input type="password" class="sec-input" id="confirmPassword" name="confirmPassword" placeholder="Xác nhận mật khẩu mới" maxlength="20" required>
                    <i class="fa-solid fa-eye toggle-password" onclick="togglePassword(this, 'confirmPassword')"></i>
                  </div>

                  <button id="btnConfirmPassword" class="sec-button" type="submit" name="changePassword">Xác nhận</button>
                </div>
              </div>
            </div>
          </form>

        </div>
  </main>

  <?php include 'footer.php'; ?>

  <!-- Back To Top Button -->
  <button id="backToTop" class="back-to-top">
    <i class="fas fa-arrow-up"></i>
  </button>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
  <script src="js/main.js"></script>
  <script src="js/account.js"></script>
  <script src="js/security.js"></script>

</body>

</html>