<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['TenNCC']);
    $email = trim($_POST['Email']);
    $phone = trim($_POST['DienThoai']);
    $address = trim($_POST['DiaChi']);

    if (!empty($name)) {
        $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE name = ?");
        $stmt->execute([$name]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $error = "Tên nhà cung cấp đã tồn tại!";
        } else {
            $insert = $pdo->prepare("INSERT INTO suppliers (name, contact_email, contact_phone, address) VALUES (?, ?, ?, ?)");
            $insert->execute([$name, $email, $phone, $address]);

            $success = "Thêm nhà cung cấp thành công!";
            header("Location: nhacungcap-list.php");
            exit();
        }
    } else {
        $error = "Vui lòng nhập tên nhà cung cấp!";
    }
}
?>



<?php if ($error): ?>
    <script type="text/javascript">
        alert("<?= $error ?>");
    </script>
<?php endif; ?>

<?php if ($success): ?>
    <script type="text/javascript">
        alert("<?= $success ?>");
    </script>
<?php endif; ?>


<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Admin</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>

    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>


    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Thêm mới</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="dashboard.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Thêm mới
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="col-md-6 col-sm-12 text-right">
                            <div class="dropdown">
                                <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown">
                                    Xuất file
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">CSV</a>
                                    <a class="dropdown-item" href="#">PDF</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Thêm mới</h4>
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php elseif ($success): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="pb-20">
                        <form method="POST">
                            <div class="form-group row">
                                <label for="TenNCC" class="col-sm-12 col-md-2 col-form-label">Tên Nhà Cung Cấp</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="TenNCC" name="TenNCC" placeholder="Nhập tên nhà cung cấp" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="Email" class="col-sm-12 col-md-2 col-form-label">Email Liên Hệ</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="email" class="form-control" id="Email" name="Email" placeholder="Nhập email liên hệ" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="DienThoai" class="col-sm-12 col-md-2 col-form-label">Số Điện Thoại</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="DienThoai" name="DienThoai" placeholder="Nhập số điện thoại" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="DiaChi" class="col-sm-12 col-md-2 col-form-label">Địa Chỉ</label>
                                <div class="col-sm-12 col-md-10">
                                    <textarea class="form-control" id="DiaChi" name="DiaChi" placeholder="Nhập địa chỉ"></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Thêm Nhà Cung Cấp</button>
                            <a href="nhacungcap-list.php" class="btn btn-secondary">Quay lại</a>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <!-- buttons for Export datatable -->
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
</body>

</html>