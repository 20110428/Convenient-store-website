<?php
require 'connect.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['ProductName'];
    $price = $_POST['Price'];
    $quantity = $_POST['Quantity'];
    $description = $_POST['Description'] ?? null;
    $categories = $_POST['Categories'];

    $img = '';
    if (!empty($_FILES['img']['name'])) {
        $imageName = time() . "_" . basename($_FILES["img"]["name"]);
        $targetDir = "img/products/";
        $targetFile = $targetDir . $imageName;

        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        move_uploaded_file($_FILES["img"]["tmp_name"], $targetFile);

        $img = $imageName;
    } else {
        $img = null; 
    }


    $stmt = $pdo->prepare("
        INSERT INTO products (name, image, quantity, price, description, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute([$name, $img, $quantity, $price, $description]);

    $productId = $pdo->lastInsertId();

    $stmt2 = $pdo->prepare("INSERT INTO product_categories (product_id, category_id) VALUES (?, ?)");

    foreach ($categories as $catId) {
        $stmt2->execute([$productId, $catId]);
    }

    header("Location: sanpham-list.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Admin</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>
    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Thêm Sản Phẩm</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="dashboard.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Thêm Sản Phẩm
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Thêm Sản Phẩm mới</h4>
                    </div>
                    <div class="pb-20">
                        <form method="POST" enctype="multipart/form-data">

                            <div class="form-group row">
                                <div class="col-sm-12 col-md-6">
                                    <label>Tên Sản Phẩm</label>
                                    <input type="text" class="form-control" name="ProductName" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 col-md-6">
                                    <label>Danh Mục</label>
                                    <select class="form-control" name="Categories[]" multiple required>
                                        <?php
                                        $categories = $pdo->query("SELECT * FROM categories")->fetchAll();
                                        foreach ($categories as $c):
                                        ?>
                                            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small>Giữ CTRL để chọn nhiều danh mục</small>
                                </div>

                                <div class="col-sm-12 col-md-6">
                                    <label>Hình Ảnh</label>
                                    <input type="file" class="form-control" name="image" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 col-md-6">
                                    <label>Giá</label>
                                    <input type="number" class="form-control" name="Price" required>
                                </div>

                                <div class="col-sm-12 col-md-6">
                                    <label>Số Lượng</label>
                                    <input type="number" class="form-control" name="Quantity" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Mô Tả</label>
                                <textarea class="form-control" name="Description" rows="3"></textarea>
                            </div>

                            <button class="btn btn-primary">Lưu</button>
                            <a href="sanpham-list.php" class="btn btn-secondary">Quay lại</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <!-- buttons for Export datatable -->
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
</body>

</html>