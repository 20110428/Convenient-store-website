<?php
require 'connect.php';
session_start();

$sql = "
    SELECT 
        o.id,
        o.note,
        v.code AS voucher_code,
        o.order_date,
        o.total_amount,
        o.status
    FROM orders o
    LEFT JOIN vouchers v ON o.voucher_id = v.id
    ORDER BY o.order_date DESC
";

$stmt = $pdo->query($sql);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);


if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];

    $stmtDetail = $pdo->prepare("DELETE FROM order_details WHERE order_id = ?");
    $stmtDetail->execute([$id]);

    $stmtDelete = $pdo->prepare("DELETE FROM orders WHERE id = ?");
    $stmtDelete->execute([$id]);

    header("Location: banhang-list.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
    <title>Danh sách đơn hàng</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="../vendors/styles/core.css">
    <link rel="stylesheet" href="../vendors/styles/icon-font.min.css">
    <link rel="stylesheet" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../vendors/styles/style.css">
</head>

<body>

    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-6">
                        <h4>Danh sách đơn hàng</h4>
                    </div>
                </div>
            </div>

            <div class="card-box mb-30">
                <div class="pd-20">
                    <h4 class="text-blue h4">Orders</h4>
                </div>

                <div class="pb-20">
                    <table class="table data-table stripe hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Voucher</th>
                                <th>Ngày đặt</th>
                                <th>Tổng tiền</th>
                                <th>Ghi chú</th>
                                <th class="datatable-nosort">Hành động</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?= $order['id'] ?></td>
                                    <td><?= $order['voucher_code'] ?? 'Không có' ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></td>
                                    <td><?= number_format($order['total_amount'], 0) ?> VND</td>
                                    <td><?= $order['note'] ?? 'Không có' ?></td>

                                    <td>
                                        <a href="banhang-detail.php?id=<?= $order['id'] ?>" class="btn btn-info btn-sm">
                                            Chi tiết
                                        </a>
                                        <a href="banhang-list.php?delete_id=<?= $order['id'] ?>"
                                            class="btn btn-danger btn-sm"
                                            onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">
                                            Xóa
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>

    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.data-table').DataTable({
                responsive: true,
                autoWidth: false
            });
        });
    </script>

</body>

</html>