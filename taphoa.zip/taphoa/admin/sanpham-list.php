<?php
require 'connect.php';

$stmt = $pdo->query("
    SELECT id, name, image, import_price, price, quantity, status, created_at, updated_at
    FROM products
    ORDER BY id DESC
");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$productCategories = [];

$stmtCat = $pdo->query("
    SELECT pc.product_id, c.name 
    FROM product_categories pc
    JOIN categories c ON pc.category_id = c.id
");
foreach ($stmtCat->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $productCategories[$row['product_id']][] = $row['name'];
}


if (isset($_GET['change_status']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $new_status = $_GET['change_status'] == 1 ? 0 : 1;

    $update = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
    $update->execute([$new_status, $id]);

    header("Location: sanpham-list.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Admin</title>

    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>

    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>


    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Danh sách</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="index.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Danh sách
                                    </li>
                                </ol>
                            </nav>
                        </div>

                    </div>
                </div>
                <div class="card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Danh sách</h4>
                    </div>
                    <div class="pb-20">
                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tên</th>
                                    <th>Hình ảnh</th>
                                    <th>Danh mục</th>
                                    <th>Giá nhập</th>
                                    <th>Giá bán</th>
                                    <th>Số lượng</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày tạo</th>
                                    <th class="datatable-nosort">Hành động</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($products as $p): ?>
                                    <tr>
                                        <td><?= $p['id'] ?></td>
                                        <td><?= htmlspecialchars($p['name']) ?></td>

                                        <td>
                                            <img src="../<?= htmlspecialchars($p['image']) ?>" width="50" height="50">
                                        </td>
                                        <td>
                                            <?php
                                            if (isset($productCategories[$p['id']])) {
                                                echo implode(", ", $productCategories[$p['id']]);
                                            } else {
                                                echo "<i>Không có</i>";
                                            }
                                            ?>
                                        </td>

                                        <td><?= number_format($p['import_price']) ?> VND</td>
                                        <td><?= number_format($p['price']) ?> VND</td>

                                        <td><?= $p['quantity'] ?></td>

                                        <td>
                                            <a href="sanpham-list.php?change_status=<?= $p['status'] ?>&id=<?= $p['id'] ?>"
                                                class="btn <?= $p['status'] == 1 ? 'btn-success' : 'btn-danger' ?>">
                                                <?= $p['status'] == 1 ? 'Khoá' : 'Mở khoá' ?>
                                            </a>
                                        </td>

                                        <td><?= $p['created_at'] ?></td>

                                        <td>
                                            <a href="sanpham-edit.php?id=<?= $p['id'] ?>" class="btn btn-warning">
                                                Cập nhật
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>

                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>

    <script>
        $(document).ready(function() {
            if ($.fn.dataTable.isDataTable('.data-table')) {
                $('.data-table').DataTable().destroy();
            }

            $('.data-table').DataTable({
                responsive: true,
                autoWidth: false,
            });
        });
    </script>

</body>

</html>