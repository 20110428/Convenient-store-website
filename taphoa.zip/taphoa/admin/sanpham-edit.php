<?php
require 'connect.php';

if (!isset($_GET['id'])) {
    die("Thiếu ID sản phẩm!");
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    die("Không tìm thấy sản phẩm!");
}

$stmt2 = $pdo->prepare("SELECT category_id FROM product_categories WHERE product_id = ?");
$stmt2->execute([$id]);
$selectedCategories = array_column($stmt2->fetchAll(PDO::FETCH_ASSOC), "category_id");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['ProductName'];
    $price = $_POST['Price'];
    $quantity = $_POST['Quantity'];
    $description = $_POST['Description'];
    $categories = $_POST['Categories'] ?? [];

    $imagePath = $product["image"];

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {

        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/taphoa/img/products/';
        $fileName = time() . '_' . basename($_FILES['image']['name']);
        $uploadPath = $uploadDir . $fileName;

        $allowed = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($_FILES['image']['type'], $allowed)) {
            die("File ảnh không hợp lệ!");
        }

        move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath);

        $imagePath = 'img/products/' . $fileName;
    }

    $stmtUpdate = $pdo->prepare("
        UPDATE products 
        SET name=?,  price=?, quantity=?, description=?, image=?, updated_at=NOW()
        WHERE id=?
    ");
    $stmtUpdate->execute([$name, $price, $quantity, $description, $imagePath, $id]);

    $pdo->prepare("DELETE FROM product_categories WHERE product_id=?")->execute([$id]);

    $stmtInsertCat = $pdo->prepare("INSERT INTO product_categories (product_id, category_id) VALUES (?, ?)");
    foreach ($categories as $catId) {
        $stmtInsertCat->execute([$id, $catId]);
    }

    header("Location: sanpham-list.php");
    exit();
}

$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

?>

<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Admin</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>
    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Cập nhật Sản Phẩm</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="dashboard.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Cập nhật Sản Phẩm
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Cập nhật Sản Phẩm mới</h4>
                    </div>
                    <div class="pb-20">
                        <form method="POST" enctype="multipart/form-data">

                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Tên Sản Phẩm</label>
                                    <input type="text" class="form-control" name="ProductName"
                                        value="<?= htmlspecialchars($product['name']) ?>" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Danh Mục</label>
                                    <select class="form-control" name="Categories[]" multiple required>
                                        <?php foreach ($categories as $c): ?>
                                            <option value="<?= $c['id'] ?>"
                                                <?= in_array($c['id'], $selectedCategories) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($c['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small>Giữ CTRL để chọn nhiều danh mục</small>
                                </div>

                                <div class="col-md-6">
                                    <label>Ảnh Hiện Tại</label><br>
                                    <img src="../<?= $product['image'] ?>" width="120" class="mb-3">
                                    <input type="file" class="form-control" name="image">
                                    <small>Chọn ảnh mới nếu muốn thay đổi</small>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label>Giá</label>
                                    <input type="number" class="form-control" name="Price"
                                        value="<?= $product['price'] ?>" required>
                                </div>

                                <div class="col-md-6">
                                    <label>Số Lượng</label>
                                    <input type="number" class="form-control" name="Quantity"
                                        value="<?= $product['quantity'] ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Mô Tả</label>
                                <textarea class="form-control" name="Description" rows="4"><?= htmlspecialchars($product['description']) ?></textarea>
                            </div>

                            <button class="btn btn-primary">Cập nhật</button>
                            <a href="sanpham-list.php" class="btn btn-secondary">Quay lại</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <!-- buttons for Export datatable -->
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
</body>

</html>