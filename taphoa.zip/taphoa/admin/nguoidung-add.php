<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['Username'];
    $password = $_POST['Password'];
    $hoTen = $_POST['HoTen'];
    $email = $_POST['Email'];
    $dienThoai = $_POST['DienThoai'];
    $diaChi = $_POST['DiaChi'];
    $role = $_POST['Role'];
    $trangThai = isset($_POST['TrangThai']) ? 1 : 0;

    if (!empty($username) && !empty($password) && !empty($hoTen) && !empty($email) && !empty($dienThoai) && !empty($role)) {

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? OR phone = ?");
        $stmt->execute([$username, $email, $dienThoai]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingUser) {
            if ($existingUser['username'] === $username) {
                $error = "Tên đăng nhập đã tồn tại!";
            } elseif ($existingUser['email'] === $email) {
                $error = "Email đã tồn tại!";
            } elseif ($existingUser['phone'] === $dienThoai) {
                $error = "Số điện thoại đã tồn tại!";
            }
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, phone, address, role, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashedPassword, $hoTen, $email, $dienThoai, $diaChi, $role, $trangThai]);

            $success = "Thêm người dùng thành công!";
            header("Location: nguoidung-list.php");
            exit();
        }
    } else {
        $error = "Vui lòng điền đầy đủ thông tin!";
    }
}
?>

<?php if ($error): ?>
    <script type="text/javascript">
        alert("<?= $error ?>");
    </script>
<?php endif; ?>

<?php if ($success): ?>
    <script type="text/javascript">
        alert("<?= $success ?>");
    </script>
<?php endif; ?>


<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Admin</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>

    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>


    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Thêm mới</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="dashboard.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Thêm mới
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="col-md-6 col-sm-12 text-right">
                            <div class="dropdown">
                                <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown">
                                    Xuất file
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">CSV</a>
                                    <a class="dropdown-item" href="#">PDF</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Thêm mới</h4>
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php elseif ($success): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="pb-20">
                        <form action="nguoidung-add.php" method="POST">
                            <div class="form-group row">
                                <label for="Username" class="col-sm-12 col-md-2 col-form-label">Username</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="Username" name="Username" placeholder="Nhập Username" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="Password" class="col-sm-12 col-md-2 col-form-label">Password</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="password" class="form-control" id="Password" name="Password" placeholder="Nhập Mật Khẩu" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="HoTen" class="col-sm-12 col-md-2 col-form-label">Tên Người Dùng</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="HoTen" name="HoTen" placeholder="Nhập Tên" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="Email" class="col-sm-12 col-md-2 col-form-label">Email</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="email" class="form-control" id="Email" name="Email" placeholder="Nhập Email" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="DienThoai" class="col-sm-12 col-md-2 col-form-label">Số Điện Thoại</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="DienThoai" name="DienThoai" placeholder="Nhập Số Điện Thoại" required />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="DiaChi" class="col-sm-12 col-md-2 col-form-label">Địa Chỉ</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="text" class="form-control" id="DiaChi" name="DiaChi" placeholder="Nhập Địa Chỉ" />
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="Role" class="col-sm-12 col-md-2 col-form-label">Role</label>
                                <div class="col-sm-12 col-md-10">
                                    <select class="form-control" id="Role" name="Role">
                                        <option value="admin">Admin</option>
                                        <option value="employee">Nhân viên</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="TrangThai" class="col-sm-12 col-md-2 col-form-label">Trạng Thái</label>
                                <div class="col-sm-12 col-md-10">
                                    <input type="checkbox" id="TrangThai" name="TrangThai" value="1" /> Hoạt Động
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Thêm Người Dùng</button>
                            <a href="nguoidung-list.php" class="btn btn-secondary">Quay lại</a>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <!-- buttons for Export datatable -->
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>

</body>

</html>