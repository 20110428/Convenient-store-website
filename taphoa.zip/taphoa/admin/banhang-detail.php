<?php
require 'connect.php';

if (!isset($_GET['id'])) {
    die('Thiếu mã đơn hàng');
}

$order_id = $_GET['id'];

/* ===============================
   LẤY THÔNG TIN ĐƠN HÀNG
================================ */
$stmt = $pdo->prepare("
    SELECT o.*, v.code AS voucher_code, v.discount_value
    FROM orders o
    LEFT JOIN vouchers v ON o.voucher_id = v.id
    WHERE o.id = ?
");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die('Đơn hàng không tồn tại');
}

/* ===============================
   LẤY CHI TIẾT SẢN PHẨM
================================ */
$stmt = $pdo->prepare("
    SELECT od.*, p.name
    FROM order_details od
    JOIN products p ON od.product_id = p.id
    WHERE od.order_id = ?
");
$stmt->execute([$order_id]);
$details = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Chi tiết đơn hàng #<?= $order_id ?></title>
    <link rel="stylesheet" href="../vendors/styles/core.css">
    <link rel="stylesheet" href="../vendors/styles/icon-font.min.css">
    <link rel="stylesheet" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../vendors/styles/style.css">

    <style>
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            background: #fff;
        }

        .invoice-box h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .invoice-box table {
            width: 100%;
            border-collapse: collapse;
        }

        .invoice-box table th,
        .invoice-box table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .invoice-box table th {
            background: #f5f5f5;
        }

        .text-right {
            text-align: right;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>
    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>

    <div class="mobile-menu-overlay"></div>
    <div class="main-container">

        <div class="invoice-box" id="invoice">
            <h2>HÓA ĐƠN BÁN HÀNG</h2>

            <p><strong>Mã đơn:</strong> #<?= $order_id ?></p>
            <p><strong>Ngày:</strong> <?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></p>

            <hr>

            <p><strong>Khách hàng:</strong> <?= htmlspecialchars($order['full_name']) ?></p>
            <p><strong>SĐT:</strong> <?= htmlspecialchars($order['phone']) ?></p>

            <hr>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sản phẩm</th>
                        <th>SL</th>
                        <th>Giá</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $subtotal = 0;
                    foreach ($details as $i => $d):
                        $lineTotal = $d['price'] * $d['quantity'];
                        $subtotal += $lineTotal;
                    ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= htmlspecialchars($d['name']) ?></td>
                            <td class="text-right"><?= $d['quantity'] ?></td>
                            <td class="text-right"><?= number_format($d['price']) ?> ₫</td>
                            <td class="text-right"><?= number_format($lineTotal) ?> ₫</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <br>

            <table>
                <tr>
                    <td><strong>Tạm tính</strong></td>
                    <td class="text-right"><?= number_format($subtotal) ?> ₫</td>
                </tr>

                <?php if ($order['voucher_id']):
                    $discount = $subtotal * $order['discount_value'] / 100;
                ?>
                    <tr>
                        <td>
                            <strong>Voucher (<?= $order['voucher_code'] ?> - <?= $order['discount_value'] ?>%)</strong>
                        </td>
                        <td class="text-right">- <?= number_format($discount) ?> ₫</td>
                    </tr>
                <?php endif; ?>

                <tr>
                    <td><strong>Tổng thanh toán</strong></td>
                    <td class="text-right"><strong><?= number_format($order['total_amount']) ?> ₫</strong></td>
                </tr>
            </table>

            <br>

            <div class="no-print text-center">
                <button onclick="window.print()" class="btn btn-primary">
                    In hóa đơn
                </button>
                <a href="banhang-list.php" class="btn btn-secondary">
                    Quay lại
                </a>
            </div>
        </div>
    </div>

</body>
<!-- JS -->
<script src="../vendors/scripts/core.js"></script>
<script src="../vendors/scripts/script.min.js"></script>
<script src="../vendors/scripts/process.js"></script>
<script src="../vendors/scripts/layout-settings.js"></script>

<script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
<script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
<script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>

</html>