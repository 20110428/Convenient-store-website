<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['user'])) {
  header("Location: ../login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $currentPassword = $_POST['currentPassword'] ?? '';
  $newPassword = $_POST['newPassword'] ?? '';
  $confirmPassword = $_POST['confirmPassword'] ?? '';
  $userId = $_SESSION['user']['id'];

  $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
  $stmt->execute([$userId]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$user || !password_verify($currentPassword, $user['password'])) {
    echo "<script>alert('Mật khẩu hiện tại không đúng!');</script>";
  } elseif ($newPassword !== $confirmPassword) {
    echo "<script>alert('Xác nhận mật khẩu mới không khớp!');</script>";
  } else {
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $update = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    $update->execute([$hashedPassword, $userId]);

    echo "<script>alert('Đổi mật khẩu thành công!');</script>";
  }
}
?>



<!DOCTYPE html>
<html>

<head>
  <!-- Basic Page Info -->
  <meta charset="utf-8" />
  <title>Admin</title>

  <!-- Site favicon -->
  <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
  <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
  <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

  <!-- Mobile Specific Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet" />
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
  <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
  <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
  <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
  <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>

  <?php include 'header.php'; ?>
  <?php include 'right.php'; ?>
  <?php include 'left.php'; ?>

  <div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
      <div class="min-height-200px">
        <div class="page-header">
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <div class="title">
                <h4>Profile</h4>
              </div>
              <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="index.html">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Profile
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-30">
            <div class="pd-20 card-box height-100-p">
              <div class="profile-photo">
                <a
                  href="modal"
                  data-toggle="modal"
                  data-target="#modal"
                  class="edit-avatar"><i class="fa fa-pencil"></i></a>
                <img
                  src="../vendors/images/photo1.jpg"
                  alt=""
                  class="avatar-photo" />
                <div
                  class="modal fade"
                  id="modal"
                  tabindex="-1"
                  role="dialog"
                  aria-labelledby="modalLabel"
                  aria-hidden="true">
                  <div
                    class="modal-dialog modal-dialog-centered"
                    role="document">
                    <div class="modal-content">
                      <div class="modal-body pd-5">
                        <div class="img-container">
                          <img
                            id="image"
                            src="../vendors/images/photo2.jpg"
                            alt="Picture" />
                        </div>
                      </div>
                      <div class="modal-footer">
                        <input
                          type="submit"
                          value="Update"
                          class="btn btn-primary" />
                        <button
                          type="button"
                          class="btn btn-default"
                          data-dismiss="modal">
                          Close
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <h5 class="text-center h5 mb-0">Nhân viên</h5>
              <p class="text-center text-muted font-14">
                Làm việc từ tháng 11 - 2025
              </p>
              <div class="profile-info">
                <h5 class="mb-20 h5 text-blue">Thông tin liên hệ</h5>
                <ul>
                  <li>
                    <span>Địa chỉ Email:</span>
                    nguyen.van.a@example.com
                  </li>
                  <li>
                    <span>Số điện thoại:</span>
                    0987-654-321
                  </li>
                  <li>
                    <span>Quốc gia:</span>
                    Việt Nam
                  </li>
                  <li>
                    <span>Địa chỉ:</span>
                    123 Đường Nguyễn Trãi<br />
                    Quận 1, TP. Hồ Chí Minh
                  </li>
                </ul>
              </div>

            </div>
          </div>
          <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 mb-30">
            <div class="card-box height-100-p overflow-hidden">
              <div class="profile-tab height-100-p">
                <div class="tab height-100-p">
                  <ul class="nav nav-tabs customtab" role="tablist">
                    <li class="nav-item active">
                      <a
                        class="nav-link"
                        data-toggle="tab"
                        href="#setting"
                        role="tab">Đổi mật khẩu</a>
                    </li>
                  </ul>
                  <div class="tab-content">
                    <div
                      class="tab-pane fade show active"
                      id="setting"
                      role="tabpanel">
                      <div class="profile-setting">
                        <form method="post">
                          <ul class="profile-edit-list row">
                            <li class="weight-500 col-md-6">
                              <h4 class="text-blue h5 mb-20">
                                Đổi mật khẩu
                              </h4>
                              <div class="form-group">
                                <label>Mật khẩu cũ</label>
                                <input
                                  class="form-control form-control-lg" name="currentPassword"
                                  type="password" />
                              </div>

                              <div class="form-group">
                                <label>Mật khẩu mới</label>
                                <input
                                  class="form-control form-control-lg" name="newPassword"
                                  type="password" />
                              </div>

                              <div class="form-group">
                                <label>Mật khẩu nhập lại</label>
                                <input
                                  class="form-control form-control-lg" name="confirmPassword"
                                  type="password" />
                              </div>
                              <div class="form-group mb-0">
                                <input
                                  type="submit"
                                  class="btn btn-primary"
                                  value="Lưu" />
                              </div>
                            </li>
                          </ul>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <script src="../vendors/scripts/core.js"></script>
  <script src="../vendors/scripts/script.min.js"></script>
  <script src="../vendors/scripts/process.js"></script>
  <script src="../vendors/scripts/layout-settings.js"></script>


</body>

</html>