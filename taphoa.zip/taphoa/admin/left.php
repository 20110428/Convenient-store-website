<div class="left-side-bar">
    <div class="brand-logo">
        <a href="dashboard.php">
            <img src="vendors/images/ConvenientStore-logo.svg" alt="" class="dark-logo" />
            <img src="vendors/images/ConvenientStore-logo-white.svg" alt="" class="light-logo" />
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>

    <div class="menu-block customscroll">
        <div class="sidebar-menu">
            <ul id="accordion-menu">
                <li>
                    <a href="dashboard.php" class="dropdown-toggle no-arrow">
                        <span class="micon bi bi-speedometer2"></span>
                        <span class="mtext">Trang chủ</span>
                    </a>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-cart-check"></span>
                        <span class="mtext">Bán hàng</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="banhang-list.php">Danh sách</a></li>
                        <li><a href="banhang-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-grid"></span>
                        <span class="mtext">Quản lý danh mục</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="danhmuc-list.php">Danh sách</a></li>
                        <li><a href="danhmuc-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-box-seam"></span>
                        <span class="mtext">Quản lý sản phẩm</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="sanpham-list.php">Danh sách</a></li>
                        <li><a href="sanpham-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                 <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-gift"></span><span class="mtext">Quản lý voucher</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="voucher-list.php">Danh sách</a></li>
                        <li><a href="voucher-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-building"></span>
                        <span class="mtext">Quản lý nhà cung cấp</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="nhacungcap-list.php">Danh sách</a></li>
                        <li><a href="nhacungcap-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-box-arrow-in-down"></span>
                        <span class="mtext">Quản lý nhập hàng</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="phieunhap-list.php">Danh sách</a></li>
                        <li><a href="phieunhap-add.php">Thêm mới</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon bi bi-people"></span>
                        <span class="mtext">Quản lý tài khoản</span>
                    </a>
                    <ul class="submenu">
                        <li><a href="nguoidung-list.php">Danh sách</a></li>
                        <li><a href="nguoidung-add.php">Thêm mới</a></li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>
</div>