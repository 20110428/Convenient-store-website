<?php
require 'connect.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $full_name   = $_POST['full_name'];
    $phone       = $_POST['phone'];
    $voucher_id  = !empty($_POST['voucher_id']) ? $_POST['voucher_id'] : null;
    $total       = $_POST['total'];
    $status      = 1;

    if (!empty($full_name) && !empty($phone) && !empty($total)) {
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare("
                INSERT INTO orders (voucher_id, order_date, total_amount, status, full_name, phone)
                VALUES (?, NOW(), ?, ?, ?, ?)
            ");
            $stmt->execute([$voucher_id, $total, $status, $full_name, $phone]);

            $order_id = $pdo->lastInsertId();

            $product_ids = $_POST['product_id'];
            $quantities  = $_POST['quantity'];
            $prices      = $_POST['price'];

            foreach ($product_ids as $key => $product_id) {

                $qty   = $quantities[$key];
                $price = $prices[$key];

                $stmtCheck = $pdo->prepare("SELECT quantity FROM products WHERE id = ?");
                $stmtCheck->execute([$product_id]);
                $product = $stmtCheck->fetch(PDO::FETCH_ASSOC);

                if (!$product || $product['quantity'] < $qty) {
                    throw new Exception("Sản phẩm không đủ tồn kho");
                }

                $stmtDetail = $pdo->prepare("
                    INSERT INTO order_details (order_id, product_id, quantity, price)
                    VALUES (?, ?, ?, ?)
                ");
                $stmtDetail->execute([$order_id, $product_id, $qty, $price]);

                $newQty = $product['quantity'] - $qty;
                $stmtUpdate = $pdo->prepare("
                    UPDATE products SET quantity = ? WHERE id = ?
                ");
                $stmtUpdate->execute([$newQty, $product_id]);
            }

            $pdo->commit();
            header("Location: banhang-list.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    } else {
        $error = "Vui lòng nhập đầy đủ thông tin!";
    }
}
?>

<?php
$stmt = $pdo->query("
                                            SELECT id, code, discount_value 
                                            FROM vouchers
                                            WHERE quantity > 0
                                            AND start_date <= CURDATE()
                                            AND end_date >= CURDATE()
                                        ");
$vouchers = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php if ($error): ?>
    <script type="text/javascript">
        alert("<?= $error ?>");
    </script>
<?php endif; ?>

<?php if ($success): ?>
    <script type="text/javascript">
        alert("<?= $success ?>");
    </script>
<?php endif; ?>

<!DOCTYPE html>
<html>

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8" />
    <title>Admin</title>

    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../vendors/images/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="../vendors/images/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="../vendors/images/favicon-16x16.png" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../vendors/styles/core.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/icon-font.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../src/plugins/datatables/css/responsive.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../vendors/styles/style.css" />
</head>

<body>
    <?php include 'header.php'; ?>
    <?php include 'right.php'; ?>
    <?php include 'left.php'; ?>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4> Tạo hoá đơn bán hàng</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="dashboard.php">Trang chủ</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Tạo hoá đơn bán hàng
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <div class="pd-20">
                        <h4 class="text-blue h4">Tạo hoá đơn bán hàng mới</h4>
                    </div>
                    <div class="pb-20">
                        <form method="POST">
                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Họ tên</label>
                                <div class="col-md-4">
                                    <input type="text" name="full_name" class="form-control" required>
                                </div>

                                <label class="col-md-2 col-form-label">SĐT</label>
                                <div class="col-md-4">
                                    <input type="text" name="phone" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 col-form-label">Voucher</label>
                                <div class="col-md-4">
                                    <select name="voucher_id" id="voucher" class="form-control">
                                        <option value="" data-discount="0">Không dùng</option>
                                        <?php foreach ($vouchers as $v): ?>
                                            <option value="<?= $v['id'] ?>"
                                                data-discount="<?= $v['discount_value'] ?>">
                                                <?= $v['code'] ?> (<?= $v['discount_value'] ?>%)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div id="product_rows">
                                <div class="form-group row align-items-end">

                                    <div class="col-md-4">
                                        <label>Sản phẩm</label>
                                        <select name="product_id[]" class="form-control" required>
                                            <option value="">Chọn</option>
                                            <?php
                                            $stmt = $pdo->query("SELECT id, name, price FROM products");
                                            foreach ($stmt as $p):
                                            ?>
                                                <option value="<?= $p['id'] ?>" data-price="<?= $p['price'] ?>">
                                                    <?= $p['name'] ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div class="col-md-2">
                                        <label>Số lượng</label>
                                        <input type="number" name="quantity[]" class="form-control" value="1" min="1">
                                    </div>

                                    <div class="col-md-2">
                                        <label>Giá bán</label>
                                        <input type="number" name="price[]" class="form-control" readonly>
                                    </div>

                                    <div class="col-md-2">
                                        <label>Tổng</label>
                                        <input type="text" name="total_price[]" class="form-control" readonly>
                                    </div>

                                </div>
                            </div>

                            <button type="button" id="add_product" class="btn btn-info">Thêm Sản Phẩm</button>

                            <div class="form-group row d-flex justify-content-end">
                                <label for="total" class="col-sm-12 col-md-2 col-form-label text-right">Tổng Tiền</label>
                                <div class="col-sm-12 col-md-2">
                                    <input type="text" class="form-control" id="total" readonly />
                                </div>
                                <input type="hidden" name="total" id="total_raw">
                            </div>


                            <button type="submit" class="btn btn-primary">Xác nhận</button>
                            <a href="banhang-list.php" class="btn btn-secondary">Quay lại</a>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../vendors/scripts/core.js"></script>
    <script src="../vendors/scripts/script.min.js"></script>
    <script src="../vendors/scripts/process.js"></script>
    <script src="../vendors/scripts/layout-settings.js"></script>
    <script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="../src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            const productRows = document.getElementById('product_rows');
            const addBtn = document.getElementById('add_product');
            const totalInput = document.getElementById('total');
            const totalRawInput = document.getElementById('total_raw');

            addBtn.addEventListener('click', function() {
                let firstRow = productRows.querySelector('.form-group');
                let newRow = firstRow.cloneNode(true);

                newRow.querySelector('select').value = '';
                newRow.querySelectorAll('input').forEach(i => i.value = '');

                productRows.appendChild(newRow);

                updateProductOptions();
                calculateTotal();
            });

            productRows.addEventListener('change', function(e) {
                if (e.target.tagName === 'SELECT' || e.target.name === 'quantity[]') {
                    updateProductOptions();
                    calculateTotal();
                }
            });

            function updateProductOptions() {
                let selectedProducts = [];

                productRows.querySelectorAll('select[name="product_id[]"]').forEach(select => {
                    if (select.value) selectedProducts.push(select.value);
                });

                productRows.querySelectorAll('select[name="product_id[]"]').forEach(select => {
                    let currentValue = select.value;

                    Array.from(select.options).forEach(option => {
                        if (option.value === '') return;

                        if (selectedProducts.includes(option.value) && option.value !== currentValue) {
                            option.style.display = 'none';
                        } else {
                            option.style.display = 'block';
                        }
                    });
                });
            }


            function calculateTotal() {
                let subtotal = 0;

                productRows.querySelectorAll('.form-group').forEach(row => {
                    let select = row.querySelector('select');
                    let qty = Number(row.querySelector('input[name="quantity[]"]').value) || 0;
                    let priceInput = row.querySelector('input[name="price[]"]');
                    let totalPriceInput = row.querySelector('input[name="total_price[]"]');

                    let price = select.selectedOptions[0]?.dataset.price || 0;
                    priceInput.value = price;

                    let rowTotal = price * qty;
                    totalPriceInput.value = formatVND(rowTotal);
                    subtotal += rowTotal;
                });


                let voucherSelect = document.getElementById('voucher');
                let discountPercent = Number(
                    voucherSelect.selectedOptions[0]?.dataset.discount || 0
                );

                let discountAmount = subtotal * discountPercent / 100;
                let finalTotal = subtotal - discountAmount;

                totalInput.value = formatVND(finalTotal);
                totalRawInput.value = finalTotal;
            }

            document.getElementById('voucher')
                .addEventListener('change', calculateTotal);



            function formatVND(number) {
                return new Intl.NumberFormat('vi-VN').format(number) + ' ₫';
            }

            updateProductOptions();
        });
    </script>

</body>

</html>